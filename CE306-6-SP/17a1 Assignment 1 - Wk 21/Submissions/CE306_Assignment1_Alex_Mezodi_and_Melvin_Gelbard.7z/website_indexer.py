#!/usr/bin/env python
"""
###############################################################################
##################### w e b s i t e _ i n d e x e r . p y #####################
###############################################################################
------------------------------------------------------------------------------#
# PURPOSE #                                                                   #
                                                                              #
This program creates a pipeline for indexing the words from a website.        #
The index could then be used by search engines for relevant queries.          #
                                                                              #
------------------------------------------------------------------------------#
# USAGE #                                                                     #
                                                                              #
When running the file, the user is asked for a url to index.                  #
Simply enter the url of the website and a file containing the indexed         #
words will be created in the same folder as this program.                     #
                                                                              #
------------------------------------------------------------------------------#
# STRUCTURE OF THE PROGRAM #                                                  #
                                                                              #
The website is processed through different steps as follow:                   #
1. Input                                                                      #
2. HTML Parsing                                                               #
3. Tokenization                                                               #
4. Finding keywords (using stoplist)                                          #
5. Stemming                                                                   #
6. Part-Of-Speech tagging                                                     #
7. Pipeline creation                                                          #
                                                                              #
Each step is explained in details in the report.                              #
                                                                              #
------------------------------------------------------------------------------#
# AUTHORS #                                                                   #
                                                                              #
Alex Mezodi (ID: 1401665) & Melvin Gelbard (ID: 1402073)                      #
                                                                              #
###############################################################################
###############################################################################
###############################################################################
"""

import urllib3
import re
import nltk
import requests
import sys
from nltk import word_tokenize
from nltk.corpus import stopwords
from nltk import re
from nltk.stem.porter import *

#------------------------------------------------------------------------------
# Routine(s)
#------------------------------------------------------------------------------

def check_url(url):
  """Check if URL is valid"""
  try:
    request = requests.get(url)
    if request.status_code == 200:
      return True
  except ValueError:
    return False

#------------------------------------------------------------------------------
# Steps of the pipeline.
#------------------------------------------------------------------------------

#===== 1. INPUT/OUTPUT (10%) =====#
def get_text_from_website(url):
  """ Please note, below we are selecting words after the first 2 words
  because the saved web html data includes b' at the beginning
  indicating that it should become a byte literal in Python 3.
  For more explanation please refer to this post below:
  https://stackoverflow.com/questions/6269765/what-does-the-b-
  character-do-in-front-of-a-string-literal
  """
  http = urllib3.PoolManager()
  return str(http.request('get', url).data)[2:]


#===== 2. HTML PARSING (10%) =====#
def clean_html(raw_html):
  """Remove HTML tags, '\n' and hyphens to replace them with a space
  hyphens example: human-rights --> 'human', 'rights', ...
  """
  regex_script = re.compile("<script(.)*</script>")
  clean_script = re.sub(regex_script, '', raw_html)
  regex_blank = re.compile('(<.*?>)|\\\\n|-|\\\\t')
  clean_text = re.sub(regex_blank, ' ', clean_script).lower()
  return clean_text


#===== 3. TOKENIZATION (10%) =====#
def tokenizer(clean_text):
  """Take every word in the string parameter and tokenises using
  'space' as a divider. Refer to 'Description of Implementation.docx'
  for more information.
  """
  return [word for word in word_tokenize(clean_text) if re.search("\w", word)]


#===== 4. REMOVE STOP WORDS (10%) =====#
def select_keywords(labelled_tokens):
  """This function takes the list parameter and removes all the stopwords in it
  according to nltk's list of stopwords in the English language.
  Refer to 'Description of Implementation.docx' for more information.
  """
  return [word for word in labelled_tokens if word not in stopwords.words('english')]


#===== 5. PART-OF-SPEECH TAGGING (10%) =====#
def tagger(list_of_tokens):
  """Take every word in the string parameter and tag them using nltk's part-
  of-speech function. Refer to the nltk help function for information about
  the abbreviation for tags.
  Refer to 'Description of Implementation.docx' for more information.
  """
  return nltk.pos_tag(list_of_tokens)


#===== 6. STEMMING (10%) =====#
def stemming(tokens_nostop):
  """Take every word in the string parameter and tag them using nltk's part-
  of-speech function. Refer to the nltk help function for information about
  the name of the tags.
  Refer to 'Description of Implementation.docx' for more information.
  """
  stemmer = PorterStemmer()
  token_new = []
  for myTuple in tokens_nostop :
    tuple_first = stemmer.stem(myTuple[0])
    tuple_second = myTuple[1]
    token_new.append((tuple_first, tuple_second))
  return token_new


#===== 7. ENGINEERING A COMPLETE SYSTEM (10%) =====#
def indexing(url):
  """This function connects all the steps of the pipeline together.
  This means that the main program (at the bottom of this file), only
  needs to make one call to completely index a website.
  Refer to 'Description of Implementation.docx' for more information.
  """
  raw = get_text_from_website(url)
  html_cleaned = clean_html(raw)
  tokens = tokenizer(html_cleaned)
  filtered_tokens = select_keywords(tokens)
  tagged_tokens = tagger(filtered_tokens)
  stemmed_tokens = stemming(tagged_tokens)
  return stemmed_tokens


#------------------------------------------------------------------------------
# Main program.
#------------------------------------------------------------------------------
url = input("Hi, please enter a valid URL for indexing: ")
if check_url(url) == True:
  index = indexing(url)
  write = input("Do you want to save the indexed tokens in a file? ")
  if write.lower() == "yes":
    with open('tokens.txt', 'w') as fid:
      fid.write(str(index))
    print("Done!")
else:
  print("\nError: URL not valid")
  sys.exit(1)

#------------------------------------------------------------------------------
# End of website_indexer.py
#------------------------------------------------------------------------------
