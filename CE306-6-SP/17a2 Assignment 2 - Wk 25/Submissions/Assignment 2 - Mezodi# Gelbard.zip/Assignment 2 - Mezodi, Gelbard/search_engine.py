#!/usr/bin/env python

"""
###############################################################################
####################### s e a r c h _ e n g i n e . p y #######################
###############################################################################
------------------------------------------------------------------------------#
# PURPOSE #                                                                   #
                                                                              #
This program creates a Graphical user Interface with which the user can	      #
interact in order to search the shakespeare json collection.        	      #
The user enters a query and clicks the "search" button to see the	      #
results.          							      #
                                                                              #
------------------------------------------------------------------------------#
# USAGE #                                                                     #
                                                                              #
On a Linux command line, the user needs to enter the following:               #
	python3 search_engine.py					      #
Then, the GUI will pop up and everything can be done on it		      #
                                                                              #
------------------------------------------------------------------------------#
# AUTHORS #                                                                   #
                                                                              #
Alex Mezodi (ID: 1401665) & Melvin Gelbard (ID: 1402073)                      #
                                                                              #
###############################################################################
###############################################################################
###############################################################################
"""

from tkinter import *
import os
import collections
import shutil
from elasticsearch import Elasticsearch
import requests
import json

class App:
	def __init__(self):
		# Testing set
		self.testing_set = [("witch","macbeth"),("bedford", "Henry VI Part 1"), 
				("sexton", "Much Ado about nothing"),("incest", "Pericles"),
				("incestuous", "Pericles"),("trojan","Troilus and Cressida"),
				("to be or not to be","Hamlet"),("bastard","King John"),
				("oracle","A Winters Tale"),("island","The Tempest")]

		# Create the root
		self.root = Tk()
		self.root.geometry("800x600+0+0")
		self.root.title("Search engine")

		# Create the parent frame
		self.Tops = Frame(self.root, width=1600, height=50, bg="purple4", relief=SUNKEN)
		self.Tops.pack()

		# Create top frame
		self.f1 = Frame(self.Tops, width=800, height=700, bg="purple4", relief=SUNKEN)
		self.f1.pack(side=TOP)

		# Create bottom frame
		self.myCanvas = Canvas(self.Tops, bg="dark slate blue")
		self.f2 = Frame(self.Tops, bg="dark slate blue", relief=SUNKEN)
		self.myScrollbar = Scrollbar(self.Tops, orient = "vertical",command = self.myCanvas.yview)
		self.myCanvas.configure(yscrollcommand=self.myScrollbar.set)
		self.myScrollbar.pack(side="right",fill="y")
		self.myCanvas.pack(side="bottom", expand=True, fill="both")
		self.myCanvas.create_window((6,6),window=self.f2,anchor='nw')
		self.f2.bind("<Configure>", self.myCanvas.configure(scrollregion=self.myCanvas.bbox("all"),width=800,height=400))


		# Elements in the top frame
		self.lbl_title = Label(self.f1, font=('arial', 35, 'bold'), text="Search Engine", fg="Steel blue", bg="purple4", bd=25, anchor='center')
		self.lbl_title.grid(row = 0, column = 0)
		self.lbl_1 = Label(self.f1, font=('arial', 12, 'bold'), text="Enter a query:", fg="Steel blue", bg="purple4", bd=25, anchor='center')
		self.lbl_1.grid(row = 1, column = 0)
		self.path_variable = StringVar()
		self.entry_query = Entry(self.f1, font=('arial', 12), textvariable=self.path_variable, bd=4, justify='right')
		self.entry_query.grid(row=2, column=0)
		self.btn_search = Button(self.f1, padx=30, pady=8, bd=4, fg="Black", text="Search", command=lambda: self.search(self.path_variable.get()))
		self.btn_search.grid(row=2, column=1)
		self.btn_map = Button(self.f1, padx=30, pady=8, bd=4, fg="Black", text="Calculate MAP", command=lambda: self.calculate_map())
		self.btn_map.grid(row=2, column=2)
		self.lbl_map = Label(self.f1, font=('arial', 9, 'bold'), text="X.XXX", fg="purple4", bg="purple4", bd=25, anchor='center')
		self.lbl_map.grid(row=2, column=3)
		self.lbl_map.lower()

		# Creating the temp folder
		if not os.path.exists("/tmp/temp"):
		    os.makedirs("/tmp/temp")
		else:
		    shutil.rmtree("/tmp/temp")
		    os.makedirs("/tmp/temp")

		self.es = Elasticsearch([{'host': 'localhost', 'port': 9200}])
		# Check if index exist already
		if not (self.es.indices.exists(index='shakespeare')):
			# Create the index 'shakespeare'
			self.es.indices.create(index = 'shakespeare', ignore=400)
			# Loads the json file
			print("Loading the json file...")
			print("This can take up to 5 min...")
			with open("shakespeare.json") as f:
				content = f.readlines()
				for i in range(0, len(content)) :
					if i%10000 == 0: 
						print(str(i) + "/111,000 Shakespeare entries...")
					content[i] = content[i][1:-2]
					content[i]  = "{" + content[i] + "\"}"
					content += "\n" 
					self.es.index(index='shakespeare', doc_type = 'books', body = json.loads(content[i]))
			print("Loading successfull!")

	def search(self, query):
		"""
		input: query (String): given by the user in the entry

		This method calls various methods to initialise precision/recall
		dictionaries and to display the relevant result to the user.
		"""
		results = self.es.search(index="shakespeare", body={"query": {"multi_match" : {"query": query, "fields": ["speaker^5","text_entry", "type", "play_name"]}},"from" : 0, "size" : 2000})
		listofRetrievedEntries = []
		for hit in results['hits']['hits']:
			listofRetrievedEntries.append(hit.get("_source"))
		for x in self.f2.winfo_children():
			x.destroy()
		if len(listofRetrievedEntries) == 0:
			self.display_no_file_frame()
		else:
			dict_of_precisions, no_tp = self.precision_at_k(query, listofRetrievedEntries)
			dict_of_recalls = {}
			
			if no_tp == True:
				self.create_evaluation_file_zero(query)
			else:
				dict_of_recalls = self.recall_at_k(query, listofRetrievedEntries)
				self.create_evaluation_file(query, dict_of_precisions)
			entry_position = 0
			for entry in listofRetrievedEntries:
					self.display_frame(entry_position, entry, dict_of_precisions, dict_of_recalls)
					entry_position += 1

	def precision_at_k(self, query, listofRetrievedEntries):
		"""
		input:
		- query (String): given by user in the entry
		- listOfRetrievedEntries (list): list of 'relevant' entries (dict) given by elasticSearch

		return:
		- dict_of_precisions (dict): dictionary with ALL the retrieved entry ranks (starting at 0)
		and their corresponding precision. E.g. {{'entry 0': 1, 'entry 1': 0.5, 'entry 2': 0.3333}
		- no_tp (boolean): indicates if it found at least one true positive
		"""
		no_tp = True
		k = 1
		TP = 0
		dict_of_precisions = {}
		for entry in listofRetrievedEntries:
			if (query, entry.get("play_name")) in self.testing_set:
				TP += 1
				no_tp = False
			dict_of_precisions["entry " + str(k-1)] = TP/k    # {entry k = precision_at_k}
			k += 1
		return dict_of_precisions, no_tp

	def recall_at_k(self, query, listofRetrievedEntries):
		"""
		input:
		- query (String): given by user in the entry
		- listOfRetrievedEntries (list): list of 'relevant' entries (dict) given by elasticSearch

		return:
		- dict_of_recalls (dict): dictionary with ALL the retrieved entry ranks (starting at 0)
		and their corresponding recall. E.g. {{'entry 0': 0.05, 'entry 1': 0.05, 'entry 2': 0.10}
		"""
		k = 1
		TP = 0
		dict_of_recalls = {}
		len_retrieved = len(listofRetrievedEntries)
		for entry in listofRetrievedEntries:
			if (query, entry.get("play_name")) in self.testing_set:
				TP += 1
			dict_of_recalls["entry " + str(k-1)] = TP/len_retrieved    # {entry k = recall_at_k}
			k += 1
		return dict_of_recalls


	def display_frame(self, entry_position, entry, dict_of_precisions, dict_of_recalls):
		individual_file_frame = Frame(self.f2, bg="dark slate blue")
		play_name = entry.get("play_name")
		speaker = entry.get("speaker")
		if speaker == "":
			speaker = "none"
		line = entry.get("text_entry")
		if len(line) > 70:
			line = line[:70] + "[...]"
		# output = entry information (first line of the frame)		
		output = "play: " + play_name + " ; speaker: " + speaker + " ; line: " + line + "\n"
		precision_here = dict_of_precisions["entry " + str(entry_position)]
		if len(dict_of_recalls) == 0:
			recall_here = 0
			f_measure = 0
		elif dict_of_recalls["entry " + str(entry_position)] == 0:
			recall_here = 0
			f_measure = 0
		else:
			recall_here = dict_of_recalls["entry " + str(entry_position)]
			f_measure = 2*(precision_here * recall_here)/(precision_here + recall_here)
		# output2 = evaluation information (second line of the frame)		
		output2 = "K = " + str(entry_position + 1) + "\t\tPrecision at k: " + str(round(precision_here,3)) + "\t\t" \
		      "Recall at k: " + str(round(recall_here,3)) + "\t\tF-measure at k: " + str(round(f_measure,3))
		final_output = output + "\n" + output2 + "\n" + str(150*"_")
		lbl_output = Label(individual_file_frame, fg="white", bg="dark slate blue", justify=LEFT,anchor="w", text=final_output)
		lbl_output.grid(row=1, column=0)
		individual_file_frame.pack(anchor="w")

	def display_no_file_frame(self):
		# Triggered if no relevant file found
		individual_file_frame = Frame(self.f2, bg="dark slate blue")
		lbl_output = Label(individual_file_frame, fg="white", bg="dark slate blue", justify=LEFT,anchor="w", text="No file found")
		lbl_output.grid(row=0, column=0)
		individual_file_frame.pack(anchor="w")
	    
	def create_evaluation_file(self, query, dict_of_precisions):
		# Create text file with information about precision
		file = open("/tmp/temp/" + query + ".txt", "w")
		total = 0.0
		for key, value in dict_of_precisions.items():
			file.write(key + "--> Precision: " + str(value) + "\n")
			total += value
		file.write(str(total/len(dict_of_precisions)))
		file.close()

	def create_evaluation_file_zero(self, query):
		# Triggered if no relevant file found
		file = open("/tmp/temp/" + query + ".txt", "w")
		file.write("No relevant file\n")
		file.write("0")
		file.close()

	    
	def calculate_map(self):
		# Return MAP of all the queries performed so far
		list_precisions = []
		number_of_files = 0
		for file in os.listdir("/tmp/temp/"):
			if file.endswith(".txt"):
				number_of_files += 1
				file_read = open("/tmp/temp/" + file, "r")
				lineList = file_read.readlines()
				file_read.close()
				list_precisions.append(lineList[-1])
		sum_precisions = 0.0
		for precision in list_precisions:
			sum_precisions += float(precision)
		lbl_map = Label(self.f1, font=('arial', 9, 'bold'), text="MAP: " + str(round(sum_precisions/number_of_files, 3)), fg="white", bg="purple4", bd=25, anchor='center')
		lbl_map.grid(row=2, column=3)
		lbl_map.lift()
		return sum_precisions/number_of_files
	    


if __name__ == '__main__':
	app = App()
	app.root.mainloop()

