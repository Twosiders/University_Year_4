package assign;

// Socket-based bank service
// Reads and writes ONE line at a time
// Print writer output is set to auto-flush

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Arrays;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class GameService implements Runnable {
    private Scanner in;
    private PrintWriter out;
    private String player;
    private boolean login;
    private Game game;

    //[2] This runs after GameServer runs
    //create a new Game instance, have players null & logged out
    public GameService(Game game, Socket socket) {
        this.game = game;
        player = null;
        login = false;
        try {
            in = new Scanner(socket.getInputStream());
            out = new PrintWriter(socket.getOutputStream(), true);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        login();
        while (login) {
            try {
                Request request = Request.parse(in.nextLine());
                String response = execute(game, request);
                // note use of \r\n for CRLF
                out.println(response + "\r\n");
            } catch (NoSuchElementException e) {
                login = false;
            }
        }
        logout();
    }

    public void login() {
        out.println("Please enter a player id (player0 - player3)");
        try {
            String input = in.nextLine().trim();
            if (game.getPlayers().contains(input)) {
                player = input;
                out.println("Welcome " + player + "!");
                System.out.println("Login: " + player);
                login = true;
            } else {
                out.println("Invalid login attempt!");
            }
            out.println(); // don't forget empty line terminator!
        } catch (NoSuchElementException e) {
        }
    }

    public void logout() {
        if (player != null) {
            System.out.println("Logout: " + player);
        }
        try {
            Thread.sleep(2000);
            in.close();
            out.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String execute(Game game, Request request) {
        System.out.println(request);
        try {
            switch (request.type) {

                case PLAYERINFO:
                    return
                            Game.player0.getPlayerinfo()+System.lineSeparator()+
                            Game.player1.getPlayerinfo()+System.lineSeparator()+
                            Game.player2.getPlayerinfo()+System.lineSeparator()+
                            Game.player3.getPlayerinfo();
                case INVALID:
                    return "Command invalid player.";
                case STOCKINFO:
                    return "Current stock prices and cards affecting them next round:"
                            +System.lineSeparator()+game.stockInfo();
                            //print stock name, price, card affecting it
                            // Apple = £100, Card = [+5]

                case VOTE:
                    Stock s = Stock.parse(request.params[0]);
                    boolean vote = Boolean.parseBoolean(request.params[1]);
                    return game.vote(game.getPlayer(player), s, vote);
                /*
                case "STARTGAME":
                    return new Request(RequestType.VOTE);
                */
                case BUY:
                    Stock s2 = Stock.parse(request.params[0]);
                    int amount = Integer.parseInt(request.params[1]);
                    return game.buy(game.getPlayer(player), s2, amount);
                case SELL:
                    Stock s3 = Stock.parse(request.params[0]);
                    int amount2 = Integer.parseInt(request.params[1]);
                    return game.sell(game.getPlayer(player), s3, amount2);
                case LOGOUT:
                    login = false;
                    return "Bye!";
                default:
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

}
