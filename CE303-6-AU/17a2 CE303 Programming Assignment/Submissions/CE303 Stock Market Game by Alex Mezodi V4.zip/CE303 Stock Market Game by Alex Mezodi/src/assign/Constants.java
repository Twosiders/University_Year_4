package assign;

public class Constants { 
	public static final String[] PLAYERS = new String[] {"player0", "player1", "player2", "player3"};
	public static final Character[] STOCK = new Character[] {'a','b','c','d','e'};
	
	// number of accounts of each customer 
	//public static final int ACCOUNTS = 3;
	

	// minimum and maximum initial balance, used for random initialisation of bank account balances 
	//public static final int MIN_INIT_BALANCE = 1000;
	
	//public static final int MAX_INIT_BALANCE = 10000;
	
	// precision for testing equality of floating point numbers
	//public static final double EPSILON = 0.001;
}
