package assign;

import java.util.*;
import java.util.function.BooleanSupplier;

public class Game {
	// create a random game
	static Player player0;
	static Player player1;
	static Player player2;
	static Player player3;
	private Map<Integer, String> players;

	//votes = Map for executeVotes()
	//voteCount = [0]Yes, [1]No
	private Map<Stock, int[]> voteCount;

	private int[] stockPrices = new int[Constants.STOCK.length];
	private int round;
	private Deck[] decks;

	//------------------------------------------------INITIALIZE
	public Game() {

		//create map of players (original method)
		players = new TreeMap<>();
		player0 = new Player(Constants.PLAYERS[0]);
		player1 = new Player(Constants.PLAYERS[1]);
		player2 = new Player(Constants.PLAYERS[2]);
		player3 = new Player(Constants.PLAYERS[3]);

		//create list of players (because of professor's tests)
		for (int i = 0; i< Constants.PLAYERS.length; i++) {
			players.put(i,Constants.PLAYERS[i]);
		}

		//set stock prices to £100
		for(int i =0; i < Stock.values().length; i++) {
			stockPrices[i] = 100;
		}

		//create new random deck
		decks = new Deck[Stock.values().length];
		for (Stock s : Stock.values()) {
			decks[s.ordinal()] = new Deck(s);
		}

		//set voteCounts to 0
		voteCount = new TreeMap<>();
		voteCount.put(Stock.Apple, new int[]{0,0});
		voteCount.put(Stock.BP, new int[]{0,0});
		voteCount.put(Stock.Cisco, new int[]{0,0});
		voteCount.put(Stock.Dell, new int[]{0,0});
		voteCount.put(Stock.Ericsson, new int[]{0,0});
	}

	// create a game with specific initial decks and share holdings
	// used for unit testing 
	public Game(Deck[] decks, int[][] shares) {

	}

	//--------------------------------------------------------GETTER METHODS
	public List<String> getPlayers() {
		ArrayList<String> playerString = new ArrayList<String>() {{
			add("player0");
			add("player1");
			add("player2");
			add("player3");
		}};
		return Collections.unmodifiableList(playerString);
	}

	public Player getPlayer(int PlayerId) {
		if(PlayerId == 0) return player0;
		if(PlayerId == 1) return player1;
		if(PlayerId == 2) return player2;
		if(PlayerId == 3) return player3;
		return null;
	}
	public int getPlayer(String PlayerId) {
		if(PlayerId.equals("player0")) return 0;
		if(PlayerId.equals("player1")) return 1;
		if(PlayerId.equals("player2")) return 2;
		if(PlayerId.equals("player3")) return 3;
		return 99;
	}

	//player's balance
	public int getCash(int playerId) {
		return getPlayer(playerId).getBalance();
	}

	//player's stocks A - 5, etc.
	public int[] getShares(int playerId) {
		int[] shares = new int[4];
		shares[0] = getPlayer(playerId).getShares(Stock.Apple);
		shares[1] = getPlayer(playerId).getShares(Stock.BP);
		shares[2] = getPlayer(playerId).getShares(Stock.Cisco);
		shares[3] = getPlayer(playerId).getShares(Stock.Dell);
		shares[4] = getPlayer(playerId).getShares(Stock.Ericsson);
		return shares;
	}

	// Stock price; A - 100, B - 105 etc.
	public int[] getPrices() {
		return stockPrices;
	}


	// Return card effects
	public Card[] getCards() {
		Card[] cards = new Card[Stock.values().length];
		for(int i =0; i<Stock.values().length; i++) {
			cards[i] = decks[i].getTopCard();
		}
		return cards;
	}

	public String stockInfo() {
		String stockInfo = "";
		int i = 0;
		for (Stock s : Stock.values()) {
			stockInfo =	stockInfo+System.lineSeparator()+
			Stock.values()[s.ordinal()]+" Value:["+getPrices()[i]+"], Card:{"+getCards()[i]+"}";
			i++;
		}
		return stockInfo;
	}

	public int getRound(){
		return round;
	}


	//----------------------------------------------------------------ACTION METHODS

	/* 2 buys per player
	*  - Check if player has actions left
	*  - Check if player has enough money to buy
	*  - Decrement actions, print info
	* */
	public String buy(int id, Stock s, int amount) {
		if(getPlayer(id).getActionsLeft() == 0) return "You have no actions left.";
		int total = Stock.parse(s,stockPrices) * amount;
		if(getPlayer(id).getBalance() < total) return "You cannot afford that.";
		//balance - total
		//player.stock(s) += amount
		else {
			getPlayer(id).setBalance(-total);
			getPlayer(id).setShares(s,+amount);
		}
		getPlayer(id).decActionsLeft();
        return "Action completed. Actions left: "+getPlayer(id).getActionsLeft()
                +System.lineSeparator()+getPlayer(id).getPlayerinfo();
	}

	/* 2 optional sells/buys per player
	- Check if player has actions left
	- Sell only stocks player owns
	- Decrement actions, print info
	*/
	public String sell(int id, Stock s, int amount) {
        if(getPlayer(id).getActionsLeft() == 0) return "You have no actions left.";
		int total = Stock.parse(s,stockPrices) * amount;
		if(getPlayer(id).getShares(s) <  amount) return "You cannot sell shares you do not own";
		else {
			getPlayer(id).setBalance(+total);
            System.out.println("PLAYER SHARES: "+getPlayer(id).getShares(s));
            getPlayer(id).setShares(s,-amount);
		}
		getPlayer(id).decActionsLeft();
		return "Action completed. Actions left: "+getPlayer(id).getActionsLeft()
                +System.lineSeparator()+getPlayer(id).getPlayerinfo();
	}

	//all votes are NO, unless voted YES
	public String vote(int id, Stock s, boolean vote) {
		if(getPlayer(id).getVotesLeft() == 0) return "You have no votes left.";
		int[] votes = voteCount.get(s);
		if(vote){//if vote = yes, +1 yes votes, else the no votes.
			votes[0] +=1;
			voteCount.put(s, votes);
		} else {
			votes[1] +=1;
			voteCount.put(s, votes);
		}
		getPlayer(id).decVotesLeft();
		//Check if everyone voted
		if(Game.player0.getVotesLeft() == 0 &&  //if all players voted, executeVotes()
				Game.player1.getVotesLeft() == 0 &&
				Game.player2.getVotesLeft() == 0 &&
				Game.player3.getVotesLeft() == 0) {
			executeVotes();
			return "Action completed. Votes left: "+getPlayer(id).getVotesLeft() +" \n"+
					"All players have finished voting. Commence next round.";
		}
		return "Action completed. Votes left: "+getPlayer(id).getVotesLeft();
	}

	/* calculate YES, NO votes
	- there are 4 players, need 3 votes at least on yes to execute
	- if voteCount[i][0] > [1] = yes wins, do this
	- execute card; meaning: remove card, influence stock
	- if voteCount[i][0] < [1] = no wins, do that
	- meaning: remove card, get new card from deck
	- if there are no votes, card remains
	*/
	public void executeVotes() {
		for (Map.Entry<Stock, int[]> entry : voteCount.entrySet()) {
			if(entry.getValue()[0]>entry.getValue()[1]) { //if there are more yes votes than no votes
				//Stock price = Stock price + decks[currentDeck[topCard.effect]];
				stockPrices[Stock.parse((entry.getKey()))] = stockPrices[Stock.parse((entry.getKey()))]
						+ decks[Stock.parse((entry.getKey()))].getTopCard().effect;
				decks[Stock.parse(entry.getKey())].removeTopCard(); //remove top card from the current stock
			} else if (entry.getValue()[0]>entry.getValue()[1]) { //if there are more NO votes
				decks[Stock.parse(entry.getKey())].removeTopCard(); //just remove top card (which automatically gets next card
			}
		}
		round++;
	}
}
