package assign;

import java.lang.reflect.Array;
import java.util.*;


public class Player {
    private final String id;
    private int balance;
    private Map<Stock, Integer> playerShares;
    private int actionsLeft;
    private int votesLeft;

    public Player(String identifier){
        this.id = identifier;
        balance = 500;
        playerShares = new TreeMap<>();
        playerShares.put(Stock.Apple,5);
        playerShares.put(Stock.BP,4);
        playerShares.put(Stock.Cisco,1);
        playerShares.put(Stock.Dell,0);
        playerShares.put(Stock.Ericsson,0);
        actionsLeft = 2;
        votesLeft = 2;
    }


    public String getId() { return id;}

    public int getBalance(){
        return balance;
    }

    public void setBalance(int amount) { balance += amount; }

    public int getShares(Stock s) {
        return playerShares.get(s);
    }

    public void setShares(Stock s, int amount) { playerShares.put(s, playerShares.get(s) + amount); }

    public String getPlayerinfo() {
        return "ID: "+getId()+" BALANCE: £"+getBalance()+ " " +
                System.lineSeparator()+"SHARES: "
                +"Apple:["+getShares(Stock.Apple)+"] "
                +"BP:["+getShares(Stock.BP)+"] "
                +"Cisco:["+getShares(Stock.Cisco)+"] "
                +"Dell:["+getShares(Stock.Dell)+"] "
                +"Ericsson:["+getShares(Stock.Ericsson)+"]"+
                System.lineSeparator()+
                "---------------------";
    }

    public int getActionsLeft() { return actionsLeft;}

    public void decActionsLeft() { actionsLeft--;}

    public int getVotesLeft() { return votesLeft;}

    public void decVotesLeft() { --votesLeft;}
}