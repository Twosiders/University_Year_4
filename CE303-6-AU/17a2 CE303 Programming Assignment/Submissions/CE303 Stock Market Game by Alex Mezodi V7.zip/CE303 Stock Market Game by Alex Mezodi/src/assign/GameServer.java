package assign;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class GameServer {

    public static final int PORT = 8888;
    public static ArrayList<GameService> gameServices;

    // sendMessageToAllPlayers
    // for every gameService
    // gameservice.out.println(message)
    public static void sendMessageToAllPlayers(String message){
        if(!(gameServices == null)) {
            for (GameService service : gameServices) {
                service.getOut().println(message);
            }
        }
    }
    //create NEW Game object
    //create new ServerSocket object (from library)
    public static void main(String[] args) throws IOException {
        Game game = new Game();
        ServerSocket server = new ServerSocket(PORT);
        System.out.println("Started GameServer at port " + PORT);
        System.out.println("Waiting for clients to connect...");

        // List of GameService
        gameServices = new ArrayList<>(4);

        //when someone connects to 8888
        //create NEW GameService Object
        //which runs on a thread
        while (gameServices.size() < 4) {
            Socket socket = server.accept();
            System.out.println("Client connected.");
//            sendMessageToAllPlayers("{+}Player connected.");
            GameService service = new GameService(game, socket);
            gameServices.add(service);
            new Thread(service).start();
        }
    }
}
