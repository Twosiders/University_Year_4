package assign;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class Tests {

	public Game game;

	// sample data
	public static Deck[] sampleDecks() {
		return new Deck[] {
				new Deck(Stock.Apple, -20, 5, 10, -5, -10, 20),
				new Deck(Stock.BP, 20, 5, 10, -5, -10, -20),
				new Deck(Stock.Cisco, 20, -5, 10, -20, -10, 5),
				new Deck(Stock.Dell, 5, -20, 10, 20, -10, -5),
				new Deck(Stock.Ericsson, -10, 10, 20, 5, -20, -5)
		};
	}

	public static int[][] sampleShares() {
		return new int[][] {
			{ 3, 0, 1, 4, 2 },
			{ 2, 2, 5, 0, 1 },
			{ 4, 1, 0, 1, 4 }
		};
	}

	@Before
	public void setup() {
		/* Apologies in advance, this is very messy due to the way I programmed it
		*  Since I initially coded the settings of player shares to the creation of a player
		*  And setShares is actually AddShares.....
		*  We gotta set those to 0 first
		* */
		game = new Game(Tests.sampleDecks());
		System.out.println(game.stockInfo());
		game.addPlayer("Thomas");
		game.addPlayer("Henry");
		game.addPlayer("Zack");
		int i = 0;
		int k = 0;
		for(Player player : game.getPlayers()) {
			for(Stock stock : Stock.values()) {
				player.resetShares(stock);
			}
		}


		for(Player player : game.getPlayers()) {

			for(Stock stock : Stock.values()) {
				player.setShares(stock, sampleShares()[i][k]);
				k++;
			}
			k=0;
			i++;
		}
	}

	@Test
	public void tradeP0() {
		game.sell(game.getPlayer("Thomas"), Stock.Apple, 3);
		game.buy(game.getPlayer("Thomas"), Stock.Cisco, 6);
		Assert.assertArrayEquals(game.getShares(game.getPlayer("Thomas")), new int[] { 0, 0, 7, 4, 2 });
		Assert.assertEquals(game.getCash(0), 182);
	}

	@Test
	public void tradeP1() {
		game.buy(game.getPlayer("Henry"), Stock.BP, 4);
		Assert.assertArrayEquals(game.getShares(game.getPlayer("Henry")), new int[] { 2, 6, 5, 0, 1 });
		Assert.assertEquals(game.getCash(1), 88);
	}

	@Test
	public void tradeP2() {
		game.sell(game.getPlayer("Zack"), Stock.Ericsson, 4);
		game.sell(game.getPlayer("Zack"), Stock.Apple, 4);
		Assert.assertArrayEquals(game.getShares(game.getPlayer("Zack")), new int[] { 0, 1, 0, 1, 0 });
		Assert.assertEquals(game.getCash(2), 1300);
	}

	@Test
	public void voteTest() {
		game.vote(game.getPlayer("Thomas"), Stock.Cisco, true);
		game.vote(game.getPlayer("Thomas"), Stock.Ericsson, false);
		game.vote(game.getPlayer("Henry"), Stock.BP, true);
		game.vote(game.getPlayer("Henry"), Stock.Cisco, true);
		game.vote(game.getPlayer("Zack"), Stock.Apple, true);
		game.vote(game.getPlayer("Zack"), Stock.BP, false);
		Assert.assertArrayEquals(game.getPrices(), new int[] { 80, 100, 120, 100, 100 });
		Card[] cards = new Card[] { new Card(5), new Card(20), new Card(-5), new Card(5), new Card(10) };
		Assert.assertArrayEquals(game.getCards(), cards);
	}

}
