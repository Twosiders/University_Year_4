package assign;

// Socket-based bank service
// Reads and writes ONE line at a time
// Print writer output is set to auto-flush

import java.io.DataOutput;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Arrays;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class GameService implements Runnable {
    private Scanner in;
    private PrintWriter out;
    private String playerString;
    private boolean login;
    private Game game;


    public PrintWriter getOut(){
        //please don't get out
        return out;
    }

    public String printPlayerInfo(){
        return game.getPlayer(playerString).getPlayerinfo();
    }

    public String printAllPlayerInfo(){
        String infos = "";
        for (Player player : game.getPlayers()) {
            infos = infos + player.getPlayerinfo() + System.lineSeparator();
        }
        return infos.trim();
    }

    //[2] This runs after GameServer runs
    //create a new Game instance, have players null & logged out
    public GameService(Game game, Socket socket) {
        this.game = game;
//        player = null;
        login = false;
        try {
            in = new Scanner(socket.getInputStream());
            out = new PrintWriter(socket.getOutputStream(), true);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        login();
        while (login) {
            try {
                Request request = Request.parse(in.nextLine());
                String response = execute(game, request);
                // note use of \r\n for CRLF
                //what to write back to the player
                out.println(response + "\r\n");
            } catch (NoSuchElementException e) {
                login = false;
            }
        }
        logout();
    }

    public void login() {
        out.println("Please enter a player id:");
        try {
            /* Save user input as player name
            *  Add it to the list of players
            *  Print some welcome messages
            *  Print info about all players
            *  Print to everyone connected that a player has joined
            * */
            playerString = in.nextLine().trim();
            if (!playerString.isEmpty()) {
                game.addPlayer(playerString);
                out.println("Welcome " + playerString + "!");
                System.out.println("Login: " + playerString);
                login = true;
                GameServer.sendMessageToAllPlayers("{+}"+playerString+" has joined the game."+System.lineSeparator());
                //print player info
                out.println(printAllPlayerInfo());
            } else {
                out.println("Invalid login attempt!");
            }
            out.println();
        } catch (NoSuchElementException e) {
        }
    }

    public void logout() {
        if (playerString != null) {
            System.out.println("Logout: " + playerString);
        }
        try {
            Thread.sleep(2000);
            in.close();
            out.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String execute(Game game, Request request) {
        System.out.println(request);
        try {
            switch (request.type) {
                case RULES:
                    return   "This online board game is about trading stocks."+System.lineSeparator()
                            +"Your goal is to accumulate the most money"+System.lineSeparator()+"over the course of 5 turns."+System.lineSeparator()
                            +"You can buy or sell stocks with your money.(Type 'HELP' for possible commands.)"+System.lineSeparator()
                            +"Please note that each trading action costs £3.00."+System.lineSeparator()
                            +"Each player can also vote for influence cards "+System.lineSeparator()+"which affect the cost of Stocks next round."+System.lineSeparator()
                            +"Each player only has 2 Trading Actions and"+System.lineSeparator()+"2 Voting actions per turn. Round ends when all players voted.";
                case HELP:
                    return   "RULES -- Read about the rules of the game."+System.lineSeparator()
                            +"PLAYERINFO -- returns information about all"+System.lineSeparator()+"players including their balance and shares."+System.lineSeparator()
                            +"STOCKINFO -- return information about all "+System.lineSeparator()+"Stock prices and cards affecting them next turn."+System.lineSeparator()
                            +"BUY -- (Format: [Command] [Stock] [Amount]) "+System.lineSeparator()+"Buy a certain number of shares in one stock."+System.lineSeparator()
                            +"SELL -- (Format: [Command] [Stock] [Amount]) "+System.lineSeparator()+"Sell a certain number of shares in one stock."+System.lineSeparator()
                            +"VOTE -- (Format: [Command] [Stock] [Yes/No] "+System.lineSeparator()+"Vote for a card to be played or not to be played next turn.)" +System.lineSeparator()
                            +"LOGOUT -- Give up the game, log out, and never return!"+System.lineSeparator();
                case PLAYERINFO:
                    return printPlayerInfo();
                case INVALID:
                    return "Command invalid playe" +
                            "r. Type 'HELP' for possible commands.";
                case STOCKINFO:
                    return "Current stock prices and cards affecting them next round:"
                            +game.stockInfo();
                case VOTE:
                    Stock s = Stock.parse(request.params[0]);
                    boolean vote = Boolean.parseBoolean(request.params[1]);
                    return game.vote(game.getPlayer(playerString), s, vote);
                /*
                case "STARTGAME":
                    return new Request(RequestType.STARTGAME);
                */
                case BUY:
                    Stock s2 = Stock.parse(request.params[0]);
                    int amount = Integer.parseInt(request.params[1]);
                    return game.buy(game.getPlayer(playerString), s2, amount);
                case SELL:
                    Stock s3 = Stock.parse(request.params[0]);
                    int amount2 = Integer.parseInt(request.params[1]);
                    return game.sell(game.getPlayer(playerString), s3, amount2);
                case LOGOUT:
                    login = false;
                    return "Bye!";
                default:
            }
//        } catch (Exception e) {
////            e.printStackTrace();
//
//        }
        } catch (RuntimeException e) {
          return "Invalid command format. Try: [Command] [Stock] [Amount/Vote]";
        }
        return "";
    }


}
