package assign;

public enum Stock {
	//Stocks
	Apple("A"), BP("B"), Cisco("C"), Dell("D"), Ericsson("E");
	Stock(String symbol) { 
		this.symbol = symbol;
	}
	public final String symbol;



	//Call stocks by their characters
	public static Stock parse(char c) {
		switch (Character.toUpperCase(c)) {
		case 'A':
			return Apple;
		case 'B':
			return BP;
		case 'C':
			return Cisco;
		case 'D':
			return Dell;
		case 'E':
			return Ericsson;
		}
		throw new RuntimeException("Stock parsing failed");
	}

	public static int parse(Stock s, int[] prices) {
		switch (s) {
			case Apple:
				return prices[0];
			case BP:
				return prices[1];
			case Cisco:
				return prices[2];
			case Dell:
				return prices[3];
			case Ericsson:
				return prices[4];
		}
		throw new RuntimeException("Stock parsing failed");
	}

	public static int parse(Stock s) {
		switch (s) {
			case Apple:
				return 0;
			case BP:
				return 1;
			case Cisco:
				return 2;
			case Dell:
				return 3;
			case Ericsson:
				return 4;
		}
		throw new RuntimeException("Stock parsing failed");
	}

	//Used for filling playerShares in a for loop
	public static Stock parse(int s) {
		switch (s) {
			case 0:
				return Apple;
			case 1:
				return BP;
			case 2:
				return Cisco;
			case 3:
				return Dell;
			case 4:
				return Ericsson;
		}
		throw new RuntimeException("Stock parsing failed");
	}


	//String to Char
	public static Stock parse(String s) {
		return parse(s.charAt(0));
	} 
	
}
