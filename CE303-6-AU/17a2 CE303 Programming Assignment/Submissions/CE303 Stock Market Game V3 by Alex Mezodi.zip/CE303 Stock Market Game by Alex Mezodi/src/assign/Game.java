package assign;

import java.util.*;
import java.util.function.BooleanSupplier;

public class Game {
	// create a random game
	static Player player0;
	static Player player1;
	static Player player2;
	static Player player3;
	private Map<Integer, String> players;

	//votes = Map for executeVotes()
	//voteCount = [0]Yes, [1]No
	private Map<Stock, int[]> voteCount;

	private int[] stockPrices = new int[Constants.STOCK.length];
	private int round;
	Deck[] decks = new Deck[Stock.values().length];

	//------------------------------------------------INITIALIZE
	public Game() {

		//create map of players (original method)
		players = new TreeMap<>();
		player0 = new Player(Constants.PLAYERS[0]);
		player1 = new Player(Constants.PLAYERS[1]);
		player2 = new Player(Constants.PLAYERS[2]);
		player3 = new Player(Constants.PLAYERS[3]);

		//create list of players (because of professor's tests)
		for (int i = 0; i< Constants.PLAYERS.length; i++) {
			players.put(i,Constants.PLAYERS[i]);
		}

		//set stock prices to £100
		for(int i : stockPrices) {
			stockPrices[i] = 100;
		}

		//create new random deck
		for (Stock s : Stock.values()) {
			decks[s.ordinal()] = new Deck(s);
		}

		//set voteCounts to 0
		voteCount = new TreeMap<>();
		voteCount.put(Stock.Apple, new int[]{0,0});
		voteCount.put(Stock.BP, new int[]{0,0});
		voteCount.put(Stock.Cisco, new int[]{0,0});
		voteCount.put(Stock.Dell, new int[]{0,0});
		voteCount.put(Stock.Ericsson, new int[]{0,0});
	}

	// create a game with specific initial decks and share holdings
	// used for unit testing 
	public Game(Deck[] decks, int[][] shares) {

	}

	//--------------------------------------------------------GETTER METHODS
	public List<String> getPlayers() {
		ArrayList<String> playerString = new ArrayList<String>() {{
			add("player0");
			add("player1");
			add("player2");
			add("player3");
		}};
		return Collections.unmodifiableList(playerString);
	}

	public Player getPlayer(int PlayerId) {
		if(PlayerId == 0) return player0;
		if(PlayerId == 1) return player1;
		if(PlayerId == 2) return player2;
		if(PlayerId == 3) return player3;
		return null;
	}

	//player's balance
	public int getCash(int playerId) {
		return getPlayer(playerId).getBalance();
	}

	//player's stocks A - 5, etc.
	public int[] getShares(int playerId) {
		int[] shares = new int[4];
		shares[0] = getPlayer(playerId).getShares(Stock.Apple);
		shares[1] = getPlayer(playerId).getShares(Stock.BP);
		shares[2] = getPlayer(playerId).getShares(Stock.Cisco);
		shares[3] = getPlayer(playerId).getShares(Stock.Dell);
		shares[4] = getPlayer(playerId).getShares(Stock.Ericsson);
		return shares;
	}

	// Stock price; A - 100, B - 105 etc.
	public int[] getPrices() {
		return stockPrices;
	}


	// Return card effects
	public Card[] getCards() {
		return new Card[] {};
	}

	public int getRound(){
		return round;
	}

	//----------------------------------------------------------------ACTION METHODS

	// 2 buys per player
	public String buy(int id, Stock s, int amount) {
		if(getPlayer(id).getActionsLeft() == 0) return "You have no actions left.";
		int total = Stock.parse(s,stockPrices) * amount;
		if(getPlayer(id).getBalance() < total) return "You cannot afford that.";
		//balance - total
		//player.stock(s) += amount
		else {
			getPlayer(id).setBalance(-total);
			getPlayer(id).setShares(s,amount);
		}
		getPlayer(id).decActionsLeft();
		return "Action completed.\n"+getPlayer(id).getPlayerinfo();
	}

	// 2 sells/buys per player
	public String sell(int id, Stock s, int amount) {
		if(getPlayer(id).getActionsLeft() == 0) return "You have no actions left.";
		int total = Stock.parse(s,stockPrices) * amount;
		if(getPlayer(id).getShares(s) <  amount) return "You cannot sell shares you do not own";
		else {
			getPlayer(id).setBalance(+total);
			getPlayer(id).setShares(s, getPlayer(id).getShares(s)-amount);
		}
		getPlayer(id).decActionsLeft();
		return "Action completed.\n"+getPlayer(id).getPlayerinfo();
	}

	// 2 votes/buys each player or skip
	//all votes are NO, unless voted YES
	public String vote(int id, Stock s, boolean vote) {
		if(getPlayer(id).getVotesLeft() == 0) return "You have no votes left.";

		//to mute the array in map, make another array and up the yes/no votes by 1
		int[] votes = voteCount.get(s);

		//if vote = yes, +1 yes votes, else the no votes.
		if(vote){
			votes[0] +=1;
			voteCount.put(s, votes;
		} else {
			votes[1] +=1;
			voteCount.put(s, votes);
		}
		getPlayer(id).decVotesLeft();
		return "Action completed. Votes left: "+getPlayer(id).getVotesLeft();
	}

	// calculate YES, NO votes
	public void executeVotes() {
		//there are 4 players, need 3 votes at least on yes to execute
		for (Map.Entry<Stock, int[]> entry : voteCount.entrySet()) {
			//if (entry.getValue()[0] == 0 && entry.getValue()[1] == 0); DO NOTHING

			if(entry.getValue()[0]>entry.getValue()[1]) { //if there are more yes votes than no

			}
		}

		round++;
	}



		//if voteCount[i][0] > [1] = yes wins, do this
		//execute card; meaning: remove card, influence stock

		//if voteCount[i][0] < [1] = no wins, do that
		//meaning: remove card, get new card from deck

		//if there are no votes, card remains

	}


}
