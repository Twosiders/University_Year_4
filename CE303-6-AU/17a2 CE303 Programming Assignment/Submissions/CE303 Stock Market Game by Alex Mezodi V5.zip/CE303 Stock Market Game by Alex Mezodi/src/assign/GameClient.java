package assign;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class GameClient {
	public static final String SERVER = "localhost";
	public Scanner in;
	public PrintWriter out;
	public Socket socket;

	public GameClient(String player) {
		try {
			socket = new Socket(SERVER, GameServer.PORT);
			InputStream instream = socket.getInputStream();
			OutputStream outstream = socket.getOutputStream();
			in = new Scanner(instream);
			// set auto-flush to true
			out = new PrintWriter(outstream, true);
			sendCommand(player);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public String sendCommand(String command) {
		StringBuffer result = new StringBuffer();
		out.println(command);
		while (true) {
			String line = in.nextLine().trim();
			if (line.isEmpty())
				break;
			result.append(line);
		}
		return result.toString();
	}



}
