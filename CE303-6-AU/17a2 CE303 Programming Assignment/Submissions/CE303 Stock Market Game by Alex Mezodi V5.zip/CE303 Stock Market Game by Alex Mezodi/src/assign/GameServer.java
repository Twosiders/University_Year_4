package assign;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class GameServer {

    public static final int PORT = 8888;

    //create NEW Game object
    //create new ServerSocket object (from library)
    public static void main(String[] args) throws IOException {
        Game game = new Game();
        ServerSocket server = new ServerSocket(PORT);
        System.out.println("Started GameServer at port " + PORT);
        System.out.println("Waiting for clients to connect...");

        //when someone connects to 8888
        //create NEW GameService Object
        //which runs on a thread
        while (true) {
            Socket socket = server.accept();
            System.out.println("Client connected.");

            GameService service = new GameService(game, socket);
            new Thread(service).start();
        }
    }
}
