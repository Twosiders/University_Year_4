package assign;

import java.lang.reflect.Array;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;


public class Player {
    private final String id;
    private int balance;
    private Map<Stock, Integer> playerShares;

    //each player gets 2 actions and votes per turn
    private int actionsLeft;
    private int votesLeft;

    //Create player, give them £500 and ...:
    public Player(String identifier){
        this.id = identifier;
        balance = 500;
        //initialize playerShares map
        playerShares = new TreeMap<>();
        playerShares.put(Stock.Apple,0);
        playerShares.put(Stock.BP,0);
        playerShares.put(Stock.Cisco,0);
        playerShares.put(Stock.Dell,0);
        playerShares.put(Stock.Ericsson,0);
        //Give players 2 actions and 2 votes to start Round 1 with
        actionsLeft = 2;
        votesLeft = 2;
        //Create a random deck with 10 randomly assigned shares
        for(int i=0; i<10; i++) {
            int rand = ThreadLocalRandom.current().nextInt(0, 4 + 1);
            setShares(Stock.parse(rand),1);
        }
    }
    // Basic getter / setter methods
    public String getId() { return id;}

    public int getBalance(){
        return balance;
    }

    public void setBalance(int amount) { balance += amount; }

    public int getShares(Stock s) {
        return playerShares.get(s);
    }

    public void setShares(Stock s, int amount) { playerShares.put(s, playerShares.get(s) + amount); }

    //Print player info such as name, balance and currently owned stocks.
    public String getPlayerinfo() {
        return "Round: "+Game.round+" ID: "+getId()+" BALANCE: £"+getBalance()+ " " +
                System.lineSeparator()+"SHARES: "
                +"Apple:["+getShares(Stock.Apple)+"] "
                +"BP:["+getShares(Stock.BP)+"] "
                +"Cisco:["+getShares(Stock.Cisco)+"] "
                +"Dell:["+getShares(Stock.Dell)+"] "
                +"Ericsson:["+getShares(Stock.Ericsson)+"]"+
                System.lineSeparator()+
                "---------------------";
    }

    public int getActionsLeft() { return actionsLeft;}

    public void decActionsLeft() { actionsLeft--;}

    public int getVotesLeft() { return votesLeft;}

    public void decVotesLeft() { --votesLeft;}

    public void resetVotesActions() {
        votesLeft = 2;
        actionsLeft = 2;
    }
}