package assign;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.BooleanSupplier;

public class Game {
	// create a random game
	private ArrayList<Player> players;

	//votes = Map for executeVotes()
	//voteCount = [0]Yes, [1]No
	private Map<Stock, int[]> voteCount;

	//how much each stock costs atm like Apple = £100
	private int[] stockPrices = new int[Stock.values().length];
	static int round;
	private Deck[] decks;

	//------------------------------------------------INITIALIZE
	public Game() {
		round = 1;
		players = new ArrayList<>();

		//set stock prices to £100
		for(int i =0; i < Stock.values().length; i++) {
			stockPrices[i] = 100;
		}

		//create new random deck
		decks = new Deck[Stock.values().length];
		for (Stock s : Stock.values()) {
			decks[s.ordinal()] = new Deck(s);
		}

		//Initialize voteCounts map to 0 votes each (yes and no votes)
		voteCount = new TreeMap<>();
		voteCount.put(Stock.Apple, new int[]{0,0});
		voteCount.put(Stock.BP, new int[]{0,0});
		voteCount.put(Stock.Cisco, new int[]{0,0});
		voteCount.put(Stock.Dell, new int[]{0,0});
		voteCount.put(Stock.Ericsson, new int[]{0,0});
	}//------------------------------



	// create a game with specific initial decks and share holdings
	// used for unit testing 
	public Game(Deck[] decks) {
		round = 1;
		players = new ArrayList<>();

		//set stock prices to £100
		for(int i =0; i < Stock.values().length; i++) {
			stockPrices[i] = 100;
		}

		//create a deck specified by the creator
		this.decks = decks;



		//set voteCounts to 0
		voteCount = new TreeMap<>();
		voteCount.put(Stock.Apple, new int[]{0,0});
		voteCount.put(Stock.BP, new int[]{0,0});
		voteCount.put(Stock.Cisco, new int[]{0,0});
		voteCount.put(Stock.Dell, new int[]{0,0});
		voteCount.put(Stock.Ericsson, new int[]{0,0});
	}

	//--------------------------------------------------------GETTER METHODS

	public ArrayList<Player> getPlayers() {
		return players;
	}

	public Player getPlayer(int PlayerId) {
		return players.get(PlayerId);
	}

	public Player getPlayer(String playerId) {
		for(Player player : players) {
			if(player.getId().equals(playerId)) return player;
		}
		System.out.println("Error. Player not added to the list of players.");
		return null;
	}

	public String getPlayerString(int PlayerId) {
		return players.get(PlayerId).getId();
	}

	//player's balance
	public int getCash(int playerId) {
		System.out.println("Player cash is: "+getPlayer(playerId).getBalance());
		return getPlayer(playerId).getBalance();
	}

	//player's stocks A - 5, etc.
	public int[] getShares(Player player) {
		int[] shares = new int[5];
		int i = 0;
		for(Stock s : Stock.values()) {
			shares[i] = player.getShares(s);
			i++;
		}
		return shares;
	}

	// Stock price; A - 100, B - 105 etc.
	public int[] getPrices() {
		return stockPrices;
	}


	// Return card effects
	public Card[] getCards() {
		Card[] cards = new Card[Stock.values().length];
		for(int i =0; i<Stock.values().length; i++) {
			cards[i] = decks[i].getTopCard();
		}
		return cards;
	}

	public String stockInfo() {
		String stockInfo = "";
		int i = 0;
		for (Stock s : Stock.values()) {
			stockInfo =	stockInfo+System.lineSeparator()+
			Stock.values()[s.ordinal()]+" Value:["+getPrices()[i]+"], Card:{"+getCards()[i]+"}";
			i++;
		}
		return stockInfo;
	}


	//----------------------------------------------------------------ACTION METHODS
	//Add players to the list
	public void addPlayer(String id) {
		players.add(new Player(id));
	}

	/* 2 buys per player
	*  - Check if player has actions left
	*  - Check if player has enough money to buy
	*  - Decrement actions, print info
	* */
	public String buy(Player id, Stock s, int amount) {
		if(id.getActionsLeft() == 0) return "You have no actions left.";
		int total = Stock.parse(s,stockPrices) * amount + (3 * amount);
		if(id.getBalance() < total) return "You cannot afford that.";
		//balance - total
		//player.stock(s) += amount
		else {
			id.setBalance(-total);
			id.setShares(s,+amount);
		}
		id.decActionsLeft();
        return "Actions left this turn: "+id.getActionsLeft()
                +System.lineSeparator()+id.getPlayerinfo();
	}

	/* 2 optional sells/buys per player
	- Check if player has actions left
	- Sell only stocks player owns
	- Decrement actions, print info
	*/
	public String sell(Player id, Stock s, int amount) {
        if(id.getActionsLeft() == 0) return "You have no actions left.";
		int total = Stock.parse(s,stockPrices) * amount;
		if(id.getShares(s) <  amount) return "You cannot sell shares you do not own";
		else {
			id.setBalance(+total);
            id.setShares(s,-amount);
		}
		id.decActionsLeft();
		return "Actions left this turn: "+id.getActionsLeft()
                +System.lineSeparator()+id.getPlayerinfo();
	}

	//all votes are NO, unless voted YES
	public String vote(Player id, Stock s, boolean vote) {
		if(id.getVotesLeft() == 0) return "You have no votes left.";
		if(id.did_I_Vote_For_This(s)) return "You cannot vote twice on the same card per turn.";
		//Temporary array to hold original values in
		int[] tempVoteCount = voteCount.get(s);
		if(vote){//if vote = yes, +1 yes votes, else the no votes.
			tempVoteCount[0] +=1;
			voteCount.put(s, tempVoteCount);
		} else {
			tempVoteCount[1] +=1;
			voteCount.put(s, tempVoteCount);
		}
		id.decVotesLeft();
		id.addAlreadyVoted(s);
		GameServer.sendMessageToAllPlayers(id.getId() + " just voted.");
		//---------------------------
		//Check if everyone voted twice
		for(Player player : players) {
			if(player.getVotesLeft() > 0){ return "Votes left this turn: "+id.getVotesLeft(); } //if any players have votes left
		}
		//If Round 5 has ended, end of the game!
		executeVotes();
		if(round > 5) { GameServer.sendMessageToAllPlayers("The game has ended. Winner(s): "+calculateWinner());
		}
		//Else end of the round! Next round
		else {
			GameServer.sendMessageToAllPlayers("All players have finished voting. Commence next round."
			+ System.lineSeparator() + stockInfo()
			+ System.lineSeparator() + printAllPlayerInfo());
		}
		return "";
	}

	/* calculate YES, NO votes
	- there are 4 players, need 3 votes at least on yes to execute
	- if voteCount[i][0] > [1] = yes wins, do this
	- execute card; meaning: remove card, influence stock
	- if voteCount[i][0] < [1] = no wins, do that
	- meaning: remove card, get new card from deck
	- if there are no votes, card remains
	*/
	public void executeVotes() {
		for (Map.Entry<Stock, int[]> entry : voteCount.entrySet()) {
			if(entry.getValue()[0]>entry.getValue()[1]) { //if there are more yes votes than no votes
				//Stock price = Stock price + decks[currentDeck[topCard.effect]];
				int stockChanged = stockPrices[Stock.parse((entry.getKey()))] + decks[Stock.parse((entry.getKey()))].getTopCard().effect;
				stockPrices[Stock.parse((entry.getKey()))] = stockChanged;
				//System.out.println("Card affecting "+Stock.parse((entry.getKey()))+" is "+ decks[Stock.parse((entry.getKey()))].getTopCard().effect);
				decks[Stock.parse(entry.getKey())].removeTopCard(); //remove top card from the current stock
			} else if (entry.getValue()[1]>entry.getValue()[0]) { //if there are more NO votes
				decks[Stock.parse(entry.getKey())].removeTopCard(); //just remove top card (which automatically gets next card
			}
		}
		round++;
		for(Player player : players) {
			player.resetVotesActions();
			player.resetAlreadyVoted();
		}
	}

	public String calculateWinner() {
		//sell all shares
		//gotta reset votes to be able sell all shares
		//selling at the end of the game doesn't cost £3.00
		for(Player player : players) {
			for(Stock share : Stock.values()){
				player.resetVotesActions();
				if(player.getShares(share)>0) {
					sell(player, share, player.getShares(share));
					player.setBalance(+3);
				}
			};
		}
		//find the biggest balance
		int best = players.get(0).getBalance();
		for(Player player : players) if(player.getBalance() > best) best = player.getBalance();
		//add everybody with that amount of money to the list of winners
		String winners = "";
		for(Player player : players) if(player.getBalance() == best) winners = winners + player.getId()+", ";

		winners = winners.substring(0, winners.length()-2) + ". With the total balance of: £"+best;
		return winners;
	}
	public String printPlayerInfo(String player){
		return getPlayer(player).getPlayerinfo();
	}

	public String printAllPlayerInfo(){
		String infos = "";
		for (Player player : getPlayers()) {
			infos = infos + player.getPlayerinfo() + System.lineSeparator();
		}
		return infos.trim();
	}
}
