package assign;

// Socket-based bank service
// Reads and writes ONE line at a time
// Print writer output is set to auto-flush

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Arrays;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class GameService implements Runnable {
    private Scanner in;
    private PrintWriter out;
    private String player;
    private boolean login;
    private Game game;

    //[2] This runs after GameServer runs
    //create a new Game instance, have players null & logged out
    public GameService(Game game, Socket socket) {
        this.game = game;
        player = null;
        login = false;
        try {
            in = new Scanner(socket.getInputStream());
            out = new PrintWriter(socket.getOutputStream(), true);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        login();
        while (login) {
            try {
                Request request = Request.parse(in.nextLine());
                String response = execute(game, request);
                // note use of \r\n for CRLF
                out.println(response + "\r\n");
            } catch (NoSuchElementException e) {
                login = false;
            }
        }
        logout();
    }

    public void login() {
        out.println("Please enter your player number such as 'player3' ");
        try {
            String input = in.nextLine().trim();

            if (game.getPlayers().contains(input)) {
                player = input;
                out.println("Welcome " + player + "!");
                System.out.println("Login: " + player);
                login = true;
            } else {
                out.println("Invalid login attempt!");
            }

            out.println(); // don't forget empty line terminator!
        } catch (NoSuchElementException e) {
        }
    }

    public void logout() {
        if (player != null) {
            System.out.println("Logout: " + player);
        }
        try {
            Thread.sleep(2000);
            in.close();
            out.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String execute(Game game, Request request) {
        System.out.println(request);
        try {
            switch (request.type) {
                /*
                case ACCOUNTS:
                    //return Arrays.toString(bank.getAccounts(customer));
                case BALANCE:
                    int accountId = Integer.parseInt(request.params[0]);
                    //return "" + bank.getBalance(customer, accountId);
                case INVALID:
                    return "Command invalid or failed!";
                case LOGOUT:
                    login = false;
                    return "Goodbye!";
                case TRANSFER:
                    int acc1 = Integer.parseInt(request.params[0]);
                    int acc2 = Integer.parseInt(request.params[1]);
                    double amount = Double.parseDouble(request.params[2]);
                    //return bank.transfer(customer, acc1, acc2, amount);
                */
                case PLAYERINFO:
                    /*return Arrays.toString(game.getPlayers(player));
                    write: Player0 [YOU]
                    Money: £500
                    Shares: A - 5, B - 2, C - 2, D - 0, E - 0
                    */

                /*
                case "STOCKINFO":
                    return new Request(RequestType.STOCKINFO);
                case "BUY":
                    return new Request(RequestType.BUY);
                case "SELL":
                    return new Request(RequestType.SELL);
                case "VOTE":
                    return new Request(RequestType.VOTE);
                */
                case LOGOUT:
                    login = false;
                    return "Bye!";
                default:
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

}
