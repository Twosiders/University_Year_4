package assign;


// Cards can be COMPARED
public final class Card implements Comparable<Card> {

	//Cards can influence stock with different values
	public static final int[] EFFECTS = new int[] { -20, -10, -5, +5, +10, +20 };
	public final int effect;
	public Card(int effect) {
		this.effect = effect;
	}

	//Write card effect
	@Override
	public String toString() {
		return "" + effect;
	}

	// ???
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + effect;
		return result;
	}

	//COMPARE cards
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		return effect == ((Card) obj).effect;
	}
	@Override
	public int compareTo(Card other) {
		return Integer.compare(effect, other.effect); 
	}

	//Exchange card string to card object (with int)
	public static Card parse(String s) { 
		int effect = Integer.parseInt(s);
		return new Card(effect);
	}
}
