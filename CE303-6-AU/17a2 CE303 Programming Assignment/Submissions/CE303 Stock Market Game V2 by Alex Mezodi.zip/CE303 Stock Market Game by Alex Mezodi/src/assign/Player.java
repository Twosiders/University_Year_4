package assign;

import java.util.Map;

/**
 * Created by amezod on 13/11/2017.
 */
public class Player {
    public final int id;
    public int balance;
    private Map<Stock, Integer> shares;

}
