package assign;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class Game {

	private List<String> players;

	// skeleton class with dummy constructors and methods 
	
	// create a random game 
	public Game() {
		players = new ArrayList<>(4);
		for(String player : Constants.PLAYERS) {
			players.add(player);
		}
	}

	// create a game with specific initial decks and share holdings
	// used for unit testing 
	public Game(Deck[] decks, int[][] shares) {

	}

	//!!! might be useless
	public List<String> getPlayers() {
		return Collections.unmodifiableList(players);

	}

	/* Check if players are logged in?
	public boolean existsCustomer(String custId) {
		return customerAccounts.containsKey(custId);
	}*/

	public int getCash(int playerId) {

		return -1;
	}

	public int[] getShares(int playerId) {

		return new int[] {};
	}

	public int[] getPrices() {

		return new int[] {};
	}

	public Card[] getCards() {

		return new Card[] {};
	}

	public void executeVotes() {
	}

	public String buy(int id, Stock s, int amount) {

		return "";
	}

	public String sell(int id, Stock s, int amount) {

		return "";
	}

	public String vote(int id, Stock s, boolean yes) {

		return "";
	}
}
