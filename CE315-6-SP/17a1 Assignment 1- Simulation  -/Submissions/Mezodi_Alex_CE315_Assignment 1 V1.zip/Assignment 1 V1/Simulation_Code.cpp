#include <stdio.h>
#include <stdlib.h>
#include "Aria.h"
#include <list>
#include <iostream>
#include <math.h>

ArRobot robot;
ArSensorReading *sonarReadingLeft, *sonarReadingFrontLeft, *sonarReadingFrontRight, *sonarReadingRight;
ArLaser *myLaser;

//variables for speed of the wheels, laser distance 
double speed1 = 100, speed2 = 100, angle1, angle2, angle3, angle4, angle5, distFront, distRight, distLeft, distRightDiag, distLeftDiag;

//variables to save sonar map data and laser map data
double sonarX, sonarY;
double distLeftX, distLeftY, distFrontX, distFrontY, distRightX, distRightY;

FILE *fpData;

void update(void);
ArGlobalFunctor updateCB(&update);

void update(void)
{
	// Set the velocity of the wheels.
	robot.setVel2(speed1, speed2);
	
	// Get sonar readings.
	sonarReadingLeft = robot.getSonarReading(0); //0 is left sonar
	sonarReadingFrontLeft = robot.getSonarReading(3); //3 is front (littlebit to left) sonar
	sonarReadingFrontRight = robot.getSonarReading(4); //4 is front (littlebit to right) sonar
	sonarReadingRight = robot.getSonarReading(7); //7 is right sonar

           
	// Get laser reading. Self explanatory left right front and diagonal lasers.
	distFront = myLaser->currentReadingPolar(-1, 1, &angle1);
	distRight = myLaser->currentReadingPolar(-90, -85, &angle2);
	distLeft = myLaser->currentReadingPolar(85, 89, &angle3);
	distRightDiag = myLaser->currentReadingPolar(-45, -43, &angle4);
	distLeftDiag = myLaser->currentReadingPolar(43, 45, &angle5);

	//Print out readings. (Most of it is commented out for clarity)
	std::cout << "Laser front: " << distFront << "\n";
	//std::cout << "Sonar right: " << sonarReadingRight->getRange() << "\n";
	//std::cout << " right: " << distRight << "\n";
	//std::cout << " left: " << distLeft << "\n";
	//std::cout << " rDiag: " << distRightDiag;
	//std::cout << " lDiag: " << distLeftDiag << "\n";

	//--------------------------------------------------------------------------- MAIN CODE FOR NAVIGATION
	//turn the robot right when you see pillars
	if (distRight < 1800 && distRight > 1300) {
		speed1 = 115, speed2 = 85;
	}
	//if robot is already turning, and see the first two columns, go straight again
	if (speed1 == 115 && speed2 == 85) {
		if (distRightDiag < 600 && distLeftDiag < 850) speed1 = 100, speed2 = 100;
	}
	//turn around the 2nd pair of pillars
	if (distRight > 700 && distRight < 800) {
		speed1 = 140, speed2 = 75;
	}
	//when right in-between 2nd pair of pillars, stop turning
	if (speed1 == 140 && speed2 == 75) {
		if (distLeft < 800 && distRight < 800){
			speed1 = 100, speed2 = 100;
		}
	}
	//stop in the end box
	if (distFront < 500){
		speed1 = 0, speed2 = 0;
		//robot.cancelConnection(); this somehow makes the robot not stop
	}
	//---------------------------------------------------------------------------


	//Calculations and Readings for the Map

	//Laser calculations 
	//all 3 steps to save processing power
	distLeftX  = (distLeft	* cos(angle3 / 180 * M_PI) + myLaser->getSensorPositionX()) * cos(robot.getTh() / 180 * M_PI) - (distLeft  * sin(angle3 / 180 * M_PI) + myLaser->getSensorPositionY()) *sin(robot.getTh() / 180 * M_PI) + robot.getX();
	distLeftY  = (distLeft  * cos(angle3 / 180 * M_PI) + myLaser->getSensorPositionX()) * sin(robot.getTh() / 180 * M_PI) + (distLeft  * sin(angle3 / 180 * M_PI) + myLaser->getSensorPositionY()) *cos(robot.getTh() / 180 * M_PI) + robot.getY();
	distFrontX = (distFront * cos(angle1 / 180 * M_PI) + myLaser->getSensorPositionX()) * cos(robot.getTh() / 180 * M_PI) - (distFront * sin(angle1 / 180 * M_PI) + myLaser->getSensorPositionY()) *sin(robot.getTh() / 180 * M_PI) +robot.getX();
	distFrontY = (distFront * cos(angle1 / 180 * M_PI) + myLaser->getSensorPositionX()) * sin(robot.getTh() / 180 * M_PI) + (distFront * sin(angle1 / 180 * M_PI) + myLaser->getSensorPositionY()) *cos(robot.getTh() / 180 * M_PI) +robot.getY();
	distRightX = (distRight * cos(angle2 / 180 * M_PI) + myLaser->getSensorPositionX()) * cos(robot.getTh() / 180 * M_PI) - (distRight * sin(angle2 / 180 * M_PI) + myLaser->getSensorPositionY()) *sin(robot.getTh() / 180 * M_PI) +robot.getX();
	distRightY = (distRight * cos(angle2 / 180 * M_PI) + myLaser->getSensorPositionX()) * sin(robot.getTh() / 180 * M_PI) + (distRight * sin(angle2 / 180 * M_PI) + myLaser->getSensorPositionY()) *cos(robot.getTh() / 180 * M_PI) +robot.getY();

	// Open a file to store data about robot coordinates, speed and obstacle / map calculations
	fpData = fopen("Data.txt", "a");
	if (fpData == NULL)
		std::cout << "File cannot be opened." << std::endl;
	fprintf(fpData, "%.2f; %.2f; %.2f; %.2f; %.2f; %.2f; %.2f; %.2f; %.2f; %.2f;", robot.getX(), robot.getY(), speed2, speed1, distLeftX, distLeftY, distFrontX, distFrontY, distRightX, distRightY);
	
	//for every 2 sonars (from sonar0 to sonar7) save map data
	for(int i=0; i<8; i=i++)
	{
			sonarX =
			//Calculating X according to the formula (3 steps in notes)
			/*Step 1 xP->*/ (robot.getSonarReading(i)->getRange() * cos(robot.getSonarReading(i)->getSensorTh() / 180 * M_PI) + robot.getSonarReading(i)->getSensorX()) 
			/*Step 2 cosRob->*/* cos(robot.getTh() / 180 * M_PI) - 
			/*Step 1 yP->*/ (robot.getSonarReading(i)->getRange() * sin(robot.getSonarReading(i)->getSensorTh() / 180 * M_PI) + robot.getSonarReading(i)->getSensorY())
			/*Step 2 sinRob->*/ *sin(robot.getTh() / 180 * M_PI)		
			/*Step 3Dist->*/ + robot.getX();
			fprintf(fpData, " %.2f; ", sonarX);

			sonarY = 
			//Calculating Y according to the formula (3 steps in notes)
			/*Step 1 xP->*/ (robot.getSonarReading(i)->getRange() * cos(robot.getSonarReading(i)->getSensorTh() / 180 * M_PI) + robot.getSonarReading(i)->getSensorX())
			/*Step 2 sinRob->*/* sin(robot.getTh() / 180 * M_PI) + 
			/*Step 1 yP->*/ (robot.getSonarReading(i)->getRange() * sin(robot.getSonarReading(i)->getSensorTh() / 180 * M_PI) + robot.getSonarReading(i)->getSensorY())
			/*Step 2 cosRob->*/ *cos(robot.getTh() / 180 * M_PI)		
			/*Step 3 Dist->*/ + robot.getY();
			fprintf(fpData, " %.2f; ", sonarY);
	}
	fprintf(fpData, "\n");

	fclose(fpData);	// Close the file.
}

int main(int argc, char **argv)
{
	// Initialisation
	Aria::init();

	ArArgumentParser argParser(&argc, argv);
	argParser.loadDefaultArguments();

	ArRobotConnector robotConnector(&argParser, &robot);
	ArLaserConnector laserConnector(&argParser, &robot, &robotConnector);

	// Always try to connect to the first laser:
	argParser.addDefaultArgument("-connectLaser");

	if (!robotConnector.connectRobot())
	{
		ArLog::log(ArLog::Terse, "Could not connect to the robot.");
		if (argParser.checkHelpAndWarnUnparsed())
		{
			// -help not given, just exit.
			Aria::logOptions();
			Aria::exit(1);
		}
	}

	// Trigger argument parsing
	if (!Aria::parseArgs() || !argParser.checkHelpAndWarnUnparsed())
	{
		Aria::logOptions();
		Aria::exit(1);
	}

	// Add sonar.
	ArSonarDevice sonar;
	robot.addRangeDevice(&sonar);

	// Connect laser.
	if (!laserConnector.connectLasers())
	{
		ArLog::log(ArLog::Terse, "Could not connect to configured laser.");
		Aria::logOptions();
		Aria::exit(1);
	}
	myLaser = robot.findLaser(1);

	ArPose space(3800, 3500, 270); // Initial robot's odometry.
	robot.moveTo(space); //Moves the robot's idea of its position to this position.

	// turn on the motors, turn off amigobot sounds
	robot.enableMotors();;

	robot.addUserTask("update", 50, &updateCB);
	//robot.setCycleTime(100);
	robot.runAsync(true);
	// wait for robot task loop to end before exiting the program
	robot.waitForRunExit();

	Aria::exit(0);
}