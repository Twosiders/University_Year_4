import nltk
#nltk.download()
#from nltk.book import*
from nltk import word_tokenize

private_eye_text = """A Message From The Headmaster
Kow tow!
That’s the Chinese for “hello”, as I’ve learnt this week, because those were the first words said to me by
the Head of our Chinese sister academy, the Tiananmen Not At All Free School.
As you’ve probably gathered, we were rolling out the school “red”(!) carpet this week for Mr Xi Sho-pping,
who was on a visit to try and buy as much of the school as we could sell him.
...
Mr Sho-pping then visited the old boiler room and we signed an agreement for him to build not only a new
nuclear boiler to replace it, but to build another two boilers, just in case the other one blows up, which
it won’t of course. Even better, all the boilers will be run entirely by himself and members of the Beijing
Nuclear Intelligence Services Department, who are delighted to be the given the chance of experimenting
with untried nuclear technology in someone else’s school. How exciting is that! I can’t have been the only
one to feel a warm glow at the thought of so much radioactivity at the very heart of the school. Who
knows, by this time next year I could be the Two-head-master! (Finkelstein, D., you’re on fire – as is the
boiler room!)
D.C."""
private_eye_tokens = word_tokenize(private_eye_text)
#print(private_eye_tokens)

#UNIGRAM TAGGER
#Import and train tagger with brown corpus
#A lot of the words were not tagged at all so it's not very accurate
from nltk.corpus import brown
unigram_tagger = nltk.tag.UnigramTagger(brown.tagged_sents(categories="news")[:5000])
print(unigram_tagger.tag(private_eye_tokens))

#HMM TAGGER
#Please note: The HMM tagger gives me an error message when attempting to print out the results.
#from nltk.corpus import brown
#hmm_tagger = nltk.hmm.HiddenMarkovModelTrainer().train_supervised(brown.tagged_sents(categories="news")[:5000])
#hmm_tagger.tag(private_eye_tokens)


