import nltk
from nltk.corpus import brown
from nltk import word_tokenize

S = "I walked 5 miles."
S_tok = word_tokenize(S)

unigram_tagger = nltk.tag.UnigramTagger(brown.tagged_sents(categories='news')[:10000])
print("Unigram tags: ",unigram_tagger.tag(S_tok))

hmm_tagger = nltk.hmm.HiddenMarkovModelTrainer().train_supervised(brown.tagged_sents(categories="news")[:10000])
print("HMM tags: ", hmm_tagger.tag(S_tok))


#=============================================================
Question2_S1 = "The prices will drop in the short term."
Question2_S2 = "The extent of the drop was very great."
S_tok1 = word_tokenize(Question2_S1)
S_tok2 = word_tokenize(Question2_S2)

print("Q2 S1 Unigram Tags: ", unigram_tagger.tag(S_tok1))
print("Q2 S2 Unigram Tags: ", unigram_tagger.tag(S_tok2))
print("Q2 S1 HMM Tags: ", hmm_tagger.tag(S_tok1))
print("Q2 S2 HMM Tags: ", hmm_tagger.tag(S_tok2))

#=============================================================

Question3_S1 = "Eye drops off shelf."
Question3_S2 = "Squad helps dog bite victim."
Q3_S_tok1 = word_tokenize(Question3_S1)
Q3_S_tok2 = word_tokenize(Question3_S2)

print("Q3 S1 Unigram Tags: ", unigram_tagger.tag(Q3_S_tok1))
print("Q3 S2 Unigram Tags: ", unigram_tagger.tag(Q3_S_tok2))
